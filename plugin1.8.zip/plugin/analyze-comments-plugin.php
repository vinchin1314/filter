<?php
/*
Plugin Name: Analyze Comments Plugin
Description: Tổng hợp số lượt bình luận, số sao đánh giá, tính trung bình số sao và lọc các bình luận theo số sao chọn
Version: 1.8
Author: Huỳnh Phú Trọng - Bùi Hiền Trung
*/

add_action('wp_enqueue_scripts', 'hpt_enqueue_scripts');
function hpt_enqueue_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_script('hpt-filter-script', plugins_url('js/filter.js', __FILE__), array('jquery'), '1.0', true);
    wp_localize_script('hpt-filter-script', 'hptAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('hpt_filter_nonce')
    ));
}

// Thêm action handler cho Ajax
add_action('wp_ajax_hpt_filter_comments', 'hpt_filter_comments_handler');
add_action('wp_ajax_nopriv_hpt_filter_comments', 'hpt_filter_comments_handler');

function hpt_filter_comments_handler() {
    check_ajax_referer('hpt_filter_nonce', 'nonce');
    
    global $wpdb;
    $rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    
    $table_name = 'Dv6_defaultcomments';
    $meta_table = 'Dv6_defaultcommentmeta';
    
    $where_clause = "WHERE c.comment_author NOT IN ('WooCommerce', 'admin') AND c.comment_post_ID = %d";
    $query_params = array($post_id);
    
    if ($rating > 0) {
        $where_clause .= " AND cm.meta_key = 'rating' AND cm.meta_value = %d";
        $query_params[] = $rating;
    }
    
    $comments = $wpdb->get_results($wpdb->prepare(
        "SELECT DISTINCT c.*, cm.meta_value as rating 
        FROM $table_name c 
        LEFT JOIN $meta_table cm ON c.comment_ID = cm.comment_id 
        $where_clause 
        ORDER BY c.comment_date DESC",
        $query_params
    ));
    
    ob_start();
    if (!empty($comments)) {
        foreach ($comments as $comment) {
            echo '<div class="comment-item" style="margin-bottom: 20px; padding: 15px; border: 1px solid #eee; border-radius: 5px;">';
            echo '<div class="comment-meta" style="margin-bottom: 10px;">';
            echo '<strong>' . esc_html($comment->comment_author) . '</strong> - ';
            echo '<span>' . date('d/m/Y H:i', strtotime($comment->comment_date)) . '</span>';
            if (!empty($comment->rating)) {
                echo ' - <span class="rating" style="color: #f1c40f;">' . str_repeat('★', $comment->rating) . '</span>';
            }
            echo '</div>';
            echo '<div class="comment-content">' . wp_kses_post($comment->comment_content) . '</div>';
            echo '</div>';
        }
    } else {
        echo '<p>Không có bình luận nào.</p>';
    }
    $html = ob_get_clean();
    
    wp_send_json_success(array('html' => $html));
}

function hpt_show_table_dv6_defaultcomments() {
    global $wpdb;

    // Tên bảng
    $table_name = 'Dv6_defaultcomments';
    $meta_table = 'Dv6_defaultcommentmeta';
    
    $post_id = get_the_ID();
    
	// Thêm đoạn code đếm tổng số bình luận
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT c.comment_ID) 
        FROM $table_name c
        WHERE c.comment_post_ID = %d 
        AND c.comment_author NOT IN ('WooCommerce', 'admin')",
        $post_id
    ));
	
    // Kiểm tra bảng tồn tại
    $table_exists = $wpdb->get_var($wpdb->prepare(
        "SHOW TABLES LIKE %s", $table_name
    ));

    // Tổng hợp đánh giá
    $ratings = [];
    $total_ratings = 0;
    $sum_ratings = 0;
    
    for ($i = 5; $i >= 1; $i--) {
        $ratings[$i] = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT c.comment_ID) 
            FROM $table_name c
            INNER JOIN $meta_table cm ON c.comment_ID = cm.comment_id 
            WHERE cm.meta_key = 'rating'
            AND cm.meta_value = %d
            AND c.comment_post_ID = %d
            AND c.comment_author NOT IN ('WooCommerce', 'admin')",
            $i, $post_id
        ));
        $total_ratings += $ratings[$i];
        $sum_ratings += $ratings[$i] * $i;
    }
    
    $average_rating = $total_ratings > 0 ? round($sum_ratings / $total_ratings, 2) : 0;

	
	 echo '<h2>Phân tích bình luận: </h2>';
        echo '<div style="margin-bottom:10px;">Tổng số lượt bình luận của ID <strong>' . esc_html($post_id) . '</strong>: <span style="color:#e67e22;">' . esc_html($count) . '</span></div>';

	
	
    echo '<div id="hpt-comments-container">';
    // Hiển thị phần tổng hợp đánh giá
    echo '<div style="margin-bottom:15px; padding:10px; background:#f8f8f8; border-radius:8px;">';
    echo '<strong>Tổng hợp đánh giá:</strong><br>';
    for ($i = 5; $i >= 1; $i--) {
        echo $i . ' sao: <span style="color:#f1c40f;font-weight:bold;">' . $ratings[$i] . '</span> ';
        echo str_repeat('★', $i) . '<br>';
    }
    echo 'Trung bình xếp hạng: <span style="color:#e67e22;font-size:18px;font-weight:bold;">' . $average_rating . ' / 5</span>';
    echo '</div>';

    if ($table_exists === $table_name) {
        // Xử lý filter
        $rating_filter = isset($_GET['rating']) ? intval($_GET['rating']) : 0;
        
        // Điều chỉnh query dựa trên filter
        $where_clause = "WHERE comment_author NOT IN ('WooCommerce', 'admin') AND comment_post_ID = %d";
        $query_params = array($post_id);
        
        if ($rating_filter > 0) {
            $where_clause .= " AND EXISTS (
                SELECT 1 FROM $meta_table cm 
                WHERE cm.comment_id = $table_name.comment_ID 
                AND cm.meta_key = 'rating' 
                AND cm.meta_value = %d
            )";
            $query_params[] = $rating_filter;
        }
        
        // Lấy dữ liệu từ bảng với filter
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name $where_clause",
            $query_params
        ));

        // CSS cho nút filter
        echo '<style>
            .hpt-table-container {
                margin: 20px auto;
                max-width: 900px;
                background: #fff;
                border-radius: 10px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.08);
                padding: 20px;
            }
            .hpt-table-container h3 {
                text-align: center;
                color: #2c3e50;
            }
            .hpt-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 15px;
            }
            .hpt-table th, .hpt-table td {
                border: 1px solid #e1e1e1;
                padding: 8px 12px;
                text-align: left;
            }
            .hpt-table th {
                background: #f5f6fa;
                color: #34495e;
                font-weight: bold;
                text-align: center;
            }
            .hpt-table tr:nth-child(even) {
                background: #fafbfc;
            }
            .hpt-table tr:hover {
                background: #f1f7ff;
            }
            .rating-filter {
                margin: 20px 0;
                text-align: center;
            }
            .filter-btn {
                display: inline-block;
                padding: 8px 15px;
                margin: 0 5px;
                border: 2px solid #3498db;
                border-radius: 20px;
                color: #3498db;
                background: white;
                cursor: pointer;
                transition: all 0.3s;
                text-decoration: none;
            }
            .filter-btn:hover {
                background: #3498db;
                color: white;
            }
            .filter-btn.active {
                background: #3498db;
                color: white;
            }
        </style>';

        echo '<div class="hpt-table-container">';
        
        // Thêm nút filter
        echo '<div class="rating-filter">';
        echo '<button data-rating="0" class="filter-btn active">Tất cả</button>';
        for ($i = 5; $i >= 1; $i--) {
            echo '<button data-rating="' . $i . '" class="filter-btn">';
            echo $i . ' ' . str_repeat('★', $i);
            echo '</button>';
        }
        echo '</div>';

      
        
        echo '</div>';
    } else {
        echo '<p style="text-align:center;">Bảng <strong>' . esc_html($table_name) . '</strong> không tồn tại.</p>';
    }

    echo '<div id="filtered-comments" class="comments-list"></div>';
    echo '</div>';
}
add_action('comment_form_after', 'hpt_show_table_dv6_defaultcomments');