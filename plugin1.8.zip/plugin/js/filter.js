jQuery(document).ready(function ($) {
  // Lưu trữ post ID
  var postId = $('input[name="comment_post_ID"]').val();

  // Hàm load comments
  function loadFilteredComments(rating) {
    $.ajax({
      url: hptAjax.ajaxurl,
      type: "POST",
      data: {
        action: "hpt_filter_comments",
        rating: rating,
        post_id: postId,
        nonce: hptAjax.nonce,
      },
      beforeSend: function () {
        $("#filtered-comments").html(
          '<p class="loading">Đang tải bình luận...</p>'
        );
      },
      success: function (response) {
        if (response.success) {
          $("#filtered-comments").html(response.data.html);
        }
      },
      error: function () {
        $("#filtered-comments").html(
          '<p class="error">Có lỗi xảy ra khi tải bình luận.</p>'
        );
      },
    });
  }

  // Xử lý click filter
  $(".rating-filter .filter-btn").on("click", function (e) {
    e.preventDefault();
    var $this = $(this);
    var rating = $this.data("rating");

    // Cập nhật trạng thái active
    $(".filter-btn").removeClass("active");
    $this.addClass("active");

    // Load comments
    loadFilteredComments(rating);
  });

  // Load tất cả comments khi trang được tải
  loadFilteredComments(0);
});
