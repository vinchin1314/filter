ANALYZE COMMENTS Plugin
Plugin WordPress phan tich va loc binh luan san pham bang sao.

Tac gia
Bui Hien Trung sunlight14321@gmail.com
Huynh Phu Trong huynhphutrong8223@gmail.com
Tinh nang
Hien thi thong ke binh luan theo sao
Cai dat
Truy cap trang web https://github.com/vinchin1314/filter
Tai file ptcmt ve
Tai tep zip tu trang Releases.
Tai len va kich hoat trong WordPress.
Cau hinh trong Settings > Phan Tich Binh Luan.
Giay phep
GPL-2.0
